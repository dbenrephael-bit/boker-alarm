package com.bokeralarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.util.Calendar

object AlarmScheduler {

    fun nextTrigger(c: Context): Long {
        val now = Calendar.getInstance()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Prefs.hour(c))
            set(Calendar.MINUTE, Prefs.minute(c))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (!cal.after(now)) cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.timeInMillis
    }

    private fun operation(c: Context): PendingIntent =
        PendingIntent.getBroadcast(
            c, 1, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        if (!Prefs.enabled(c)) {
            am.cancel(operation(c))
            return
        }
        val t = nextTrigger(c)
        val show = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            am.setAlarmClock(AlarmManager.AlarmClockInfo(t, show), operation(c))
        } catch (e: SecurityException) {
            // exact alarms not allowed (Android 12): fall back to an inexact alarm
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, operation(c))
        }
    }
}
