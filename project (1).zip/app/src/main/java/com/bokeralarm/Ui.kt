package com.bokeralarm

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val BG = Color.parseColor("#14121F")
    val CARD = Color.parseColor("#221F33")
    val ACCENT = Color.parseColor("#FFB020")
    val TEXT = Color.parseColor("#F5F2EA")
    val MUTED = Color.parseColor("#A9A3BC")
    val WARN = Color.parseColor("#FF6B6B")
    val GOOD = Color.parseColor("#5DD39E")

    fun dp(c: Context, v: Int): Int = (v * c.resources.displayMetrics.density).toInt()

    fun column(c: Context, padDp: Int = 20): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        val p = dp(c, padDp)
        setPadding(p, p, p, p)
    }

    fun row(c: Context): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.HORIZONTAL
        layoutDirection = View.LAYOUT_DIRECTION_RTL
        gravity = Gravity.CENTER_VERTICAL
    }

    fun text(c: Context, s: String, sizeSp: Float = 17f, color: Int = TEXT, bold: Boolean = false): TextView =
        TextView(c).apply {
            text = s
            textSize = sizeSp
            setTextColor(color)
            textDirection = View.TEXT_DIRECTION_RTL
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setLineSpacing(0f, 1.15f)
        }

    fun rounded(color: Int, radiusPx: Float, strokeColor: Int? = null, strokePx: Int = 0) =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx
            if (strokeColor != null) setStroke(strokePx, strokeColor)
        }

    fun card(c: Context): LinearLayout = column(c, 16).apply {
        background = rounded(CARD, dp(c, 18).toFloat())
    }

    fun button(c: Context, s: String, primary: Boolean = true, onClick: () -> Unit): Button =
        Button(c).apply {
            text = s
            isAllCaps = false
            textSize = 17f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(if (primary) BG else TEXT)
            background = rounded(
                if (primary) ACCENT else CARD, dp(c, 14).toFloat(),
                if (primary) null else MUTED, dp(c, 1)
            )
            val p = dp(c, 12)
            setPadding(p, p, p, p)
            stateListAnimator = null
            setOnClickListener { onClick() }
        }

    fun lp(c: Context, topDp: Int = 0, w: Int = ViewGroup.LayoutParams.MATCH_PARENT): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(c, topDp)
        }
}

fun LinearLayout.add(v: View, topDp: Int = 0): View {
    addView(v, Ui.lp(context, topDp))
    return v
}
