package com.bokeralarm

import android.content.Context
import android.content.SharedPreferences
import java.time.LocalDate

object Prefs {
    const val TASK_MATH = "MATH"
    const val TASK_MODEH = "MODEH"
    const val TASK_PHOTO = "PHOTO"
    const val TASK_PUSHUPS = "PUSHUPS"
    const val TASK_RANDOM = "RANDOM"
    const val TASK_ALL = "ALL"

    private fun sp(c: Context): SharedPreferences =
        c.getSharedPreferences("boker", Context.MODE_PRIVATE)

    fun hour(c: Context) = sp(c).getInt("hour", 6)
    fun minute(c: Context) = sp(c).getInt("minute", 30)
    fun setTime(c: Context, h: Int, m: Int) =
        sp(c).edit().putInt("hour", h).putInt("minute", m).apply()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, v: Boolean) = sp(c).edit().putBoolean("enabled", v).apply()

    fun task(c: Context): String = sp(c).getString("task", TASK_RANDOM) ?: TASK_RANDOM
    fun setTask(c: Context, v: String) = sp(c).edit().putString("task", v).apply()

    fun pushups(c: Context) = sp(c).getInt("pushups", 10)
    fun setPushups(c: Context, v: Int) = sp(c).edit().putInt("pushups", v).apply()

    fun streak(c: Context): Int {
        val last = sp(c).getString("lastDay", "") ?: ""
        val today = LocalDate.now()
        // a streak is still alive if the last win was today or yesterday
        return if (last == today.toString() || last == today.minusDays(1).toString())
            sp(c).getInt("streak", 0) else 0
    }

    /** Records a successful wake-up and returns the new streak. */
    fun recordWin(c: Context): Int {
        val today = LocalDate.now()
        val last = sp(c).getString("lastDay", "") ?: ""
        val old = sp(c).getInt("streak", 0)
        val streak = when (last) {
            today.toString() -> old
            today.minusDays(1).toString() -> old + 1
            else -> 1
        }
        sp(c).edit().putInt("streak", streak).putString("lastDay", today.toString()).apply()
        return streak
    }
}
