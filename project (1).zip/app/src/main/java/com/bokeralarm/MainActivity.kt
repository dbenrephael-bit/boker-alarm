package com.bokeralarm

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var timeText: TextView
    private lateinit var nextText: TextView
    private lateinit var streakText: TextView
    private lateinit var pushText: TextView
    private lateinit var enabledSwitch: Switch
    private lateinit var permBox: LinearLayout

    private val tasks = listOf(
        Prefs.TASK_MATH to "🧮  תרגילי חשבון",
        Prefs.TASK_MODEH to "🙏  מודה אני בקול",
        Prefs.TASK_PHOTO to "📸  צילום (מברשת / מיטה / שמיים)",
        Prefs.TASK_PUSHUPS to "💪  שכיבות סמיכה",
        Prefs.TASK_RANDOM to "🎲  אקראי - משימה אחרת כל בוקר",
        Prefs.TASK_ALL to "⚡  בוקר שוקר - כל המשימות ברצף",
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = Ui.column(this)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            addView(root)
        }
        setContentView(scroll)

        root.add(Ui.text(this, "בוקר שוקר שלי", 28f, Ui.ACCENT, bold = true))
        root.add(Ui.text(this, "השעון לא נכבה עד שקמת באמת.", 15f, Ui.MUTED), 2)

        // --- alarm card ---
        val alarmCard = Ui.card(this)
        root.add(alarmCard, 20)
        timeText = Ui.text(this, "", 64f, Ui.TEXT, bold = true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { pickTime() }
        }
        alarmCard.add(timeText)
        alarmCard.add(Ui.text(this, "לחץ על השעה כדי לשנות", 13f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        })
        enabledSwitch = Switch(this).apply {
            text = "שעון פעיל"
            textSize = 18f
            setTextColor(Ui.TEXT)
            layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL
            setOnCheckedChangeListener { _, on ->
                Prefs.setEnabled(this@MainActivity, on)
                AlarmScheduler.schedule(this@MainActivity)
                refresh()
            }
        }
        alarmCard.add(enabledSwitch, 14)
        nextText = Ui.text(this, "", 14f, Ui.MUTED)
        alarmCard.add(nextText, 4)

        // --- permissions warnings ---
        permBox = Ui.column(this, 0)
        root.add(permBox, 12)

        // --- task card ---
        val taskCard = Ui.card(this)
        root.add(taskCard, 16)
        taskCard.add(Ui.text(this, "איך מכבים את השעון?", 19f, Ui.TEXT, bold = true))
        val group = RadioGroup(this).apply { layoutDirection = android.view.View.LAYOUT_DIRECTION_RTL }
        tasks.forEachIndexed { i, (key, label) ->
            val rb = RadioButton(this).apply {
                id = 1000 + i
                text = label
                textSize = 16f
                setTextColor(Ui.TEXT)
                buttonTintList = android.content.res.ColorStateList.valueOf(Ui.ACCENT)
                val p = Ui.dp(this@MainActivity, 6)
                setPadding(p, p, p, p)
            }
            group.addView(rb)
            if (Prefs.task(this) == key) rb.isChecked = true
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setTask(this, tasks[id - 1000].first)
        }
        taskCard.add(group, 8)

        // pushups count
        val pushRow = Ui.row(this)
        pushRow.addView(Ui.text(this, "כמה שכיבות סמיכה:", 16f), Ui.lp(this, 0, 0).apply { weight = 1f })
        pushRow.addView(Ui.button(this, "−", primary = false) { changePush(-5) })
        pushText = Ui.text(this, "", 20f, Ui.ACCENT, bold = true).apply {
            gravity = Gravity.CENTER
            minWidth = Ui.dp(this@MainActivity, 56)
        }
        pushRow.addView(pushText)
        pushRow.addView(Ui.button(this, "+", primary = false) { changePush(5) })
        taskCard.add(pushRow, 12)

        // --- streak + test ---
        streakText = Ui.text(this, "", 18f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER }
        root.add(streakText, 20)

        root.add(Ui.button(this, "נסה עכשיו ▶") {
            AlarmService.start(this, test = true)
        }, 16)
        root.add(Ui.text(this,
            "בניסיון השעון מצלצל באמת ונכבה רק אחרי המשימה, כדי שתראה שהכול עובד.",
            13f, Ui.MUTED), 6)

        askBasicPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        timeText.text = String.format(Locale.US, "%02d:%02d", Prefs.hour(this), Prefs.minute(this))
        enabledSwitch.setOnCheckedChangeListener(null)
        enabledSwitch.isChecked = Prefs.enabled(this)
        enabledSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.setEnabled(this, on)
            AlarmScheduler.schedule(this)
            refresh()
        }
        nextText.text = if (Prefs.enabled(this)) {
            val t = AlarmScheduler.nextTrigger(this)
            val left = (t - System.currentTimeMillis()) / 60000
            val fmt = SimpleDateFormat("EEEE HH:mm", Locale("he"))
            "הצלצול הבא: ${fmt.format(Date(t))}  (בעוד ${left / 60} שעות ו-${left % 60} דקות)"
        } else "השעון כבוי"
        pushText.text = Prefs.pushups(this).toString()
        val s = Prefs.streak(this)
        streakText.text = if (s > 0) "🔥 רצף: $s ימים" else "🔥 עוד אין רצף. מחר מתחילים!"
        buildPermissionWarnings()
    }

    private fun pickTime() {
        TimePickerDialog(this, { _, h, m ->
            Prefs.setTime(this, h, m)
            Prefs.setEnabled(this, true)
            AlarmScheduler.schedule(this)
            refresh()
            Toast.makeText(this, "השעון נקבע ✅", Toast.LENGTH_SHORT).show()
        }, Prefs.hour(this), Prefs.minute(this), true).show()
    }

    private fun changePush(d: Int) {
        val v = (Prefs.pushups(this) + d).coerceIn(5, 50)
        Prefs.setPushups(this, v)
        pushText.text = v.toString()
    }

    private fun askBasicPermissions() {
        val need = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 7)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun buildPermissionWarnings() {
        permBox.removeAllViews()
        fun warn(msg: String, btn: String, action: () -> Unit) {
            val card = Ui.column(this, 14).apply {
                background = Ui.rounded(Ui.CARD, Ui.dp(this@MainActivity, 14).toFloat(), Ui.WARN, Ui.dp(this@MainActivity, 1))
            }
            card.add(Ui.text(this, "⚠️ $msg", 15f))
            card.add(Ui.button(this, btn, primary = false) { action() }, 8)
            permBox.add(card, 8)
        }
        val nm = getSystemService(NotificationManager::class.java)

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) warn("צריך לאשר התראות, אחרת השעון לא יוכל להופיע.", "אשר התראות") {
            openAppSettings()
        }

        if (Build.VERSION.SDK_INT >= 34 && !nm.canUseFullScreenIntent())
            warn("צריך לאשר \"התראות במסך מלא\" כדי שמסך השעון יקפוץ גם כשהטלפון נעול.", "פתח הגדרה") {
                startSafe(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            }

        if (Build.VERSION.SDK_INT in 31..32 &&
            !getSystemService(AlarmManager::class.java).canScheduleExactAlarms()
        ) warn("צריך לאשר \"שעונים מעוררים ותזכורות\" כדי שהשעון יצלצל בזמן.", "פתח הגדרה") {
            startSafe(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            warn("משימת \"מודה אני\" צריכה גישה למיקרופון.", "אשר מיקרופון") {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 8)
            }

        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName))
            warn("מומלץ לבטל \"חיסכון בסוללה\" לאפליקציה, כדי שהטלפון לא יעצור את השעון בלילה. בחר באפליקציה \"בוקר שוקר שלי\" וסמן \"ללא הגבלה\".", "פתח הגדרה") {
                startSafe(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
    }

    private fun openAppSettings() {
        startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun startSafe(i: Intent) {
        try { startActivity(i) } catch (e: Exception) { openAppSettingsFallback() }
    }

    private fun openAppSettingsFallback() {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        } catch (e: Exception) { }
    }
}
