package com.bokeralarm

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator

class AlarmService : Service() {

    companion object {
        const val ACTION_START = "start"
        const val ACTION_MUTE = "mute"
        const val ACTION_UNMUTE = "unmute"
        const val ACTION_STOP = "stop"
        const val EXTRA_TEST = "test"
        const val CHANNEL = "alarm_channel"
        const val NOTIF_ID = 42

        @Volatile var running = false
        @Volatile var isTest = false

        fun start(c: Context, test: Boolean) {
            val i = Intent(c, AlarmService::class.java)
                .setAction(ACTION_START).putExtra(EXTRA_TEST, test)
            c.startForegroundService(i)
        }

        fun send(c: Context, action: String) {
            if (!running) return
            c.startService(Intent(c, AlarmService::class.java).setAction(action))
        }
    }

    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val handler = Handler(Looper.getMainLooper())
    private val unmute = Runnable { setLoud(true) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin(intent.getBooleanExtra(EXTRA_TEST, false))
            ACTION_MUTE -> {
                setLoud(false)
                // never stay quiet for long
                handler.removeCallbacks(unmute)
                handler.postDelayed(unmute, 25_000)
            }
            ACTION_UNMUTE -> {
                handler.removeCallbacks(unmute)
                setLoud(true)
            }
            ACTION_STOP -> {
                finishAlarm()
                return START_NOT_STICKY
            }
            else -> if (!running) stopSelf()
        }
        return START_STICKY
    }

    private fun begin(test: Boolean) {
        isTest = test
        val notif = buildNotification(test)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(NOTIF_ID, notif)
        }
        if (running) return
        running = true

        val pm = getSystemService(PowerManager::class.java)
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "boker:alarm").apply {
            acquire(60 * 60 * 1000L)
        }

        val am = getSystemService(AudioManager::class.java)
        am.setStreamVolume(
            AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0
        )

        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AlarmService, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            player = null
        }

        vibrator = getSystemService(Vibrator::class.java)
        vibrate()

        // try to open the ring screen right away (works when the app is allowed to)
        try {
            startActivity(ringIntent(test).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    private fun vibrate() {
        vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 600), 0))
    }

    private fun setLoud(loud: Boolean) {
        if (loud) {
            player?.setVolume(1f, 1f)
            vibrate()
        } else {
            player?.setVolume(0f, 0f)
            vibrator?.cancel()
        }
    }

    private fun ringIntent(test: Boolean) =
        Intent(this, RingActivity::class.java).putExtra(EXTRA_TEST, test)

    private fun buildNotification(test: Boolean): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CHANNEL) == null) {
            val ch = NotificationChannel(CHANNEL, "שעון מעורר", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(null, null)
            ch.enableVibration(false)
            ch.setBypassDnd(true)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            this, 3, ringIntent(test).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("⏰ בוקר טוב! הגיע הזמן לקום")
            .setContentText("לחץ כאן ובצע את המשימה כדי לכבות")
            .setCategory(Notification.CATEGORY_ALARM)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
    }

    private fun finishAlarm() {
        handler.removeCallbacks(unmute)
        running = false
        try { player?.stop() } catch (e: Exception) { }
        player?.release()
        player = null
        vibrator?.cancel()
        wakeLock?.let { if (it.isHeld) it.release() }
        wakeLock = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        if (running) {
            running = false
            handler.removeCallbacks(unmute)
            player?.release()
            vibrator?.cancel()
            wakeLock?.let { if (it.isHeld) it.release() }
        }
        super.onDestroy()
    }
}
