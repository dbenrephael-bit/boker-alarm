package com.bokeralarm

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class RingActivity : Activity(), SensorEventListener {

    private lateinit var body: LinearLayout
    private lateinit var clock: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var queue = mutableListOf<String>()
    private var step = 0
    private var test = false
    private var done = false

    // speech
    private var recognizer: SpeechRecognizer? = null

    // pushups
    private var sensorManager: SensorManager? = null
    private var proximity: Sensor? = null
    private var isNear = false
    private var lastCount = 0L
    private var pushCount = 0
    private var pushTarget = 10
    private var pushLabel: TextView? = null

    // photo
    private var photoStatus: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            clock.text = SimpleDateFormat("HH:mm", Locale.US).format(Date())
            handler.postDelayed(this, 10_000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        test = intent.getBooleanExtra(AlarmService.EXTRA_TEST, false) || AlarmService.isTest
        if (!AlarmService.running) {
            finish()
            return
        }

        val root = Ui.column(this, 22)
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Ui.BG)
            isFillViewport = true
            addView(root)
        })
        clock = Ui.text(this, "", 72f, Ui.ACCENT, bold = true).apply { gravity = Gravity.CENTER }
        root.add(clock, 10)
        root.add(Ui.text(this, if (test) "🧪 ניסיון" else "בוקר טוב! ☀️", 22f, Ui.TEXT, bold = true).apply {
            gravity = Gravity.CENTER
        })
        body = Ui.column(this, 0)
        root.add(body, 24)

        queue = when (val t = Prefs.task(this)) {
            Prefs.TASK_ALL -> mutableListOf(Prefs.TASK_MATH, Prefs.TASK_MODEH, Prefs.TASK_PHOTO, Prefs.TASK_PUSHUPS)
            Prefs.TASK_RANDOM -> mutableListOf(
                listOf(Prefs.TASK_MATH, Prefs.TASK_MODEH, Prefs.TASK_PHOTO, Prefs.TASK_PUSHUPS).random()
            )
            else -> mutableListOf(t)
        }
        handler.post(tick)
        showStep()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // no escape: the alarm only stops after the task
    }

    // ------------------------------------------------------------------ flow

    private fun header(): String =
        if (queue.size > 1) "משימה ${step + 1} מתוך ${queue.size}" else "כדי לכבות את השעון:"

    private fun showStep() {
        stopSensors()
        body.removeAllViews()
        if (step >= queue.size) {
            win()
            return
        }
        body.add(Ui.text(this, header(), 15f, Ui.MUTED).apply { gravity = Gravity.CENTER })
        when (queue[step]) {
            Prefs.TASK_MATH -> showMath()
            Prefs.TASK_MODEH -> showModeh()
            Prefs.TASK_PHOTO -> showPhoto()
            Prefs.TASK_PUSHUPS -> showPushups()
        }
    }

    private fun next() {
        AlarmService.send(this, AlarmService.ACTION_UNMUTE)
        step++
        showStep()
    }

    /** Replaces the current task with maths (used when a sensor or service is missing). */
    private fun fallbackToMath(reason: String) {
        queue[step] = Prefs.TASK_MATH
        showStep()
        body.add(Ui.text(this, reason, 14f, Ui.WARN).apply { gravity = Gravity.CENTER }, 10)
    }

    private fun win() {
        done = true
        AlarmService.send(this, AlarmService.ACTION_STOP)
        val streak = if (test) Prefs.streak(this) else Prefs.recordWin(this)
        body.add(Ui.text(this, "🎉", 80f).apply { gravity = Gravity.CENTER })
        body.add(Ui.text(this, "כל הכבוד, קמת!", 30f, Ui.GOOD, bold = true).apply { gravity = Gravity.CENTER }, 8)
        body.add(Ui.text(this,
            if (test) "הניסיון עבר בהצלחה. מחר זה אמיתי 😉" else "🔥 רצף: $streak ימים",
            20f, Ui.TEXT).apply { gravity = Gravity.CENTER }, 12)
        body.add(Ui.button(this, "סגור") { finishAndRemoveTask() }, 30)
    }

    // ------------------------------------------------------------------ maths

    private var mathSolved = 0
    private var mathAnswer = 0

    private fun showMath() {
        mathSolved = 0
        val card = Ui.card(this)
        body.add(card, 12)
        card.add(Ui.text(this, "🧮 פתור 3 תרגילים", 20f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER })
        val progress = Ui.text(this, "", 14f, Ui.MUTED).apply { gravity = Gravity.CENTER }
        card.add(progress, 4)
        val problem = Ui.text(this, "", 40f, Ui.ACCENT, bold = true).apply {
            gravity = Gravity.CENTER
            textDirection = android.view.View.TEXT_DIRECTION_LTR
        }
        card.add(problem, 14)
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_SIGNED
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Ui.TEXT)
            setHintTextColor(Ui.MUTED)
            hint = "התשובה"
            imeOptions = EditorInfo.IME_ACTION_DONE
        }
        card.add(input, 10)
        val feedback = Ui.text(this, "", 15f, Ui.WARN).apply { gravity = Gravity.CENTER }
        card.add(feedback, 6)

        fun newProblem() {
            val a = Random.nextInt(12, 30)
            val b = Random.nextInt(3, 10)
            val c = Random.nextInt(10, 100)
            mathAnswer = a * b + c
            problem.text = "$a × $b + $c"
            progress.text = "תרגיל ${mathSolved + 1} מתוך 3"
            input.setText("")
        }

        fun check() {
            val v = input.text.toString().trim().toIntOrNull()
            if (v == mathAnswer) {
                mathSolved++
                feedback.text = ""
                if (mathSolved >= 3) next() else newProblem()
            } else {
                feedback.text = "לא נכון. הנה תרגיל חדש 🙃"
                newProblem()
            }
        }

        input.setOnEditorActionListener { _, _, _ -> check(); true }
        card.add(Ui.button(this, "בדוק") { check() }, 10)
        newProblem()
        input.requestFocus()
    }

    // ------------------------------------------------------------------ modeh ani

    private val modehText =
        "מוֹדֶה אֲנִי לְפָנֶיךָ, מֶלֶךְ חַי וְקַיָּם, שֶׁהֶחֱזַרְתָּ בִּי נִשְׁמָתִי בְּחֶמְלָה, רַבָּה אֱמוּנָתֶךָ."
    private val modehWords = listOf(
        "מודה", "אני", "לפניך", "מלך", "חי", "וקיים", "קיים",
        "שהחזרת", "החזרת", "בי", "נשמתי", "בחמלה", "חמלה", "רבה", "אמונתך"
    )

    private fun showModeh() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            fallbackToMath("זיהוי דיבור לא זמין בטלפון, אז במקום זה: חשבון.")
            return
        }
        val card = Ui.card(this)
        body.add(card, 12)
        card.add(Ui.text(this, "🙏 אמור בקול רם:", 20f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER })
        card.add(Ui.text(this, modehText, 26f, Ui.ACCENT, bold = true).apply { gravity = Gravity.CENTER }, 14)
        val status = Ui.text(this, "לחץ על הכפתור ותתחיל לדבר. השעון יושתק לרגע.", 15f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }
        card.add(status, 14)
        card.add(Ui.button(this, "🎤 התחל להקליט") {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 9)
                status.text = "אשר גישה למיקרופון ולחץ שוב."
            } else listen(status)
        }, 12)
    }

    private fun normalize(s: String) =
        s.replace(Regex("[\\u0591-\\u05C7]"), "").replace(Regex("[^\\u05D0-\\u05EA ]"), " ")

    private fun listen(status: TextView) {
        recognizer?.destroy()
        AlarmService.send(this, AlarmService.ACTION_MUTE)
        status.text = "👂 מקשיב... דבר עכשיו"
        status.setTextColor(Ui.ACCENT)
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    AlarmService.send(this@RingActivity, AlarmService.ACTION_UNMUTE)
                    val all = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                    val best = all.maxOfOrNull { r ->
                        val words = normalize(r).split(" ").filter { it.isNotBlank() }.toSet()
                        modehWords.count { it in words }
                    } ?: 0
                    if (best >= 6) {
                        next()
                    } else {
                        status.setTextColor(Ui.WARN)
                        status.text = "לא שמעתי את כל המשפט (${all.firstOrNull() ?: "שקט"}). נסה שוב, חזק וברור."
                    }
                }

                override fun onError(error: Int) {
                    AlarmService.send(this@RingActivity, AlarmService.ACTION_UNMUTE)
                    status.setTextColor(Ui.WARN)
                    status.text = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            "לא שמעתי כלום. לחץ שוב ודבר חזק."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "אין גישה למיקרופון."
                        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                            "אין אינטרנט לזיהוי דיבור. נסה שוב."
                        else -> "משהו השתבש ($error). נסה שוב."
                    }
                }

                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "⏳ בודק..." }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "he-IL")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 2500L)
            })
        }
    }

    // ------------------------------------------------------------------ photo

    private val photoTargets = listOf(
        "את מברשת השיניים שלך, בחדר האמבטיה",
        "את המיטה שלך - מסודרת!",
        "את השמיים מהחלון",
    )

    private fun showPhoto() {
        val target = photoTargets.random()
        val card = Ui.card(this)
        body.add(card, 12)
        card.add(Ui.text(this, "📸 צלם:", 20f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER })
        card.add(Ui.text(this, target, 26f, Ui.ACCENT, bold = true).apply { gravity = Gravity.CENTER }, 12)
        card.add(Ui.text(this, "צריך לקום ולהדליק אור. תמונה חשוכה לא תתקבל 😉", 14f, Ui.MUTED).apply {
            gravity = Gravity.CENTER
        }, 10)
        photoStatus = Ui.text(this, "", 15f, Ui.WARN).apply { gravity = Gravity.CENTER }
        card.add(photoStatus!!, 8)
        card.add(Ui.button(this, "📷 פתח מצלמה") {
            try {
                startActivityForResult(Intent(MediaStore.ACTION_IMAGE_CAPTURE), 55)
            } catch (e: Exception) {
                fallbackToMath("לא נמצאה מצלמה, אז במקום זה: חשבון.")
            }
        }, 12)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 55) return
        @Suppress("DEPRECATION")
        val bmp = data?.extras?.get("data") as? Bitmap
        if (resultCode != RESULT_OK || bmp == null) {
            photoStatus?.text = "לא צולמה תמונה. נסה שוב."
            return
        }
        val b = brightness(bmp)
        if (b < 55) {
            photoStatus?.text = "התמונה חשוכה מדי. תדליק אור ונסה שוב 💡"
        } else {
            next()
        }
    }

    private fun brightness(bmp: Bitmap): Double {
        var sum = 0.0
        var n = 0
        val stepX = maxOf(1, bmp.width / 30)
        val stepY = maxOf(1, bmp.height / 30)
        var y = 0
        while (y < bmp.height) {
            var x = 0
            while (x < bmp.width) {
                val p = bmp.getPixel(x, y)
                val r = (p shr 16) and 0xff
                val g = (p shr 8) and 0xff
                val bl = p and 0xff
                sum += 0.299 * r + 0.587 * g + 0.114 * bl
                n++
                x += stepX
            }
            y += stepY
        }
        return if (n == 0) 0.0 else sum / n
    }

    // ------------------------------------------------------------------ pushups

    private fun showPushups() {
        sensorManager = getSystemService(SensorManager::class.java)
        proximity = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
        if (proximity == null) {
            fallbackToMath("אין חיישן קרבה בטלפון, אז במקום זה: חשבון.")
            return
        }
        pushTarget = Prefs.pushups(this)
        pushCount = 0
        isNear = false
        val card = Ui.card(this)
        body.add(card, 12)
        card.add(Ui.text(this, "💪 $pushTarget שכיבות סמיכה", 22f, Ui.TEXT, bold = true).apply { gravity = Gravity.CENTER })
        card.add(Ui.text(this,
            "שים את הטלפון על הרצפה, מסך כלפי מעלה, מתחת לפנים שלך. " +
            "בכל ירידה קרב את האף לחלק העליון של המסך (שם החיישן) - וכל ירידה תיספר.",
            15f, Ui.MUTED).apply { gravity = Gravity.CENTER }, 10)
        pushLabel = Ui.text(this, "0 / $pushTarget", 64f, Ui.ACCENT, bold = true).apply { gravity = Gravity.CENTER }
        card.add(pushLabel!!, 16)
        sensorManager?.registerListener(this, proximity, SensorManager.SENSOR_DELAY_GAME)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val max = proximity?.maximumRange ?: 5f
        val near = event.values[0] < minOf(max, 5f)
        val now = System.currentTimeMillis()
        if (near && !isNear && now - lastCount > 700) {
            lastCount = now
            pushCount++
            pushLabel?.text = "$pushCount / $pushTarget"
            if (pushCount >= pushTarget) {
                handler.postDelayed({ next() }, 400)
            }
        }
        isNear = near
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun stopSensors() {
        sensorManager?.unregisterListener(this)
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopSensors()
        recognizer?.destroy()
        super.onDestroy()
    }
}
